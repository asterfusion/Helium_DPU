.. Define the common option --node-name-map

**--node-name-map <node-name-map>** Specify a node name map.

        This file maps GUIDs to more user friendly names.  See FILES section.

