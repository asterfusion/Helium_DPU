This directory contains assorted programs for generating test vectors
from other crypto libraries, like OpenSSL.
