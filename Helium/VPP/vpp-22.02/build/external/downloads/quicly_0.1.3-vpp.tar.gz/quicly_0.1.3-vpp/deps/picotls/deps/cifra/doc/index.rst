.. Cifra documentation master file, created by
   sphinx-quickstart on Sat Feb 21 18:02:37 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Cifra's documentation!
=================================

Contents:

.. toctree::
   :maxdepth: 2

   cf_config
   prp
   chash
   aes
   norx
   salsa20
   modes
   hmac
   poly1305
   chacha20poly1305
   pbkdf2
   sha1
   sha2
   sha3
   drbg

Index
-----
* :ref:`genindex`

